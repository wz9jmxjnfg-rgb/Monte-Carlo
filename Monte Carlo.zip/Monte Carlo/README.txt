Hallo Frau Heitbaum,

in der Datei „monte_carlo_ergebnisse“ befinden sich die Ergebnisse, die ich beim Ausführen des Skripts erhalten habe. Wenn Sie das Skript selbst ausführen, werden Ihre Ergebnisse natürlich leicht abweichen. Die prozentualen Werte sollten jedoch in etwa gleich bleiben.

Mit freundlichen Grüßen
Elias

0011101000101001


