import random
import math

START_CAPITAL = 100
TARGET_CAPITAL = 200
STAKE = 5
TRIALS = 10000
SEED = 20260312

def theoretical_success_probability(start_capital, target_capital, stake, p):
    i = start_capital / stake
    N = target_capital / stake
    q = 1 - p
    if abs(p - 0.5) < 1e-12:
        return i / N
    r = q / p
    return (1 - r**i) / (1 - r**N)

def simulate_ruin(start_capital, target_capital, stake, p, trials, seed=0, max_steps=100000):
    rng = random.Random(seed)
    success = 0
    ruin = 0
    unfinished = 0
    steps_total = 0

    for _ in range(trials):
        capital = start_capital
        steps = 0
        while 0 < capital < target_capital and steps < max_steps:
            if rng.random() < p:
                capital += stake
            else:
                capital -= stake
            steps += 1

        steps_total += steps

        if capital >= target_capital:
            success += 1
        elif capital <= 0:
            ruin += 1
        else:
            unfinished += 1

    return success / trials, ruin / trials, unfinished, steps_total / trials

cases = [
    ("Faires Münzwurfmodell", 0.5),
    ("Unfaires Münzwurfmodell", 0.49),
]

for idx, (name, p) in enumerate(cases, start=1):
    theo_success = theoretical_success_probability(START_CAPITAL, TARGET_CAPITAL, STAKE, p)
    theo_ruin = 1 - theo_success
    sim_success, sim_ruin, unfinished, avg_steps = simulate_ruin(
        START_CAPITAL, TARGET_CAPITAL, STAKE, p, TRIALS, seed=SEED + idx
    )
    print(name)
    print(f"  p = {p:.6f}, q = {1-p:.6f}")
    print(f"  Theoretische Erfolgswahrscheinlichkeit: {theo_success:.4f}")
    print(f"  Theoretische Ruinwahrscheinlichkeit:    {theo_ruin:.4f}")
    print(f"  Simulierte Erfolgswahrscheinlichkeit:  {sim_success:.4f}")
    print(f"  Simulierte Ruinwahrscheinlichkeit:     {sim_ruin:.4f}")
    print(f"  Unfertige Durchläufe:                  {unfinished}")
    print(f"  Durchschnittliche Rundenzahl:          {avg_steps:.2f}")
    print()
